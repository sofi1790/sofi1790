var addressPoints = [
  [
    "Abington, Oxfordshire | Coseners | <a href='https://coseners.net/wp-content/uploads/2022/07/cosners_waleed_iqbal_2022_final.pdf'>Lady and tramp Nextdoor: Online manifestations of real-world inequalities</a>",
    51.67109,
    -1.28278
  ],
];
