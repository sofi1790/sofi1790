<!-- ---
title: "INFO-203: Social Aspects of Information Systems (Spring 2012)"
collection: teaching
teaching_type: "Graduate course"
permalink: /teaching/spring12-social-info
institution: "UC-Berkeley School of Information"
date: 2012-01-01
excerpt: "<i>Graduate course, Teaching assistant</i><br/>
INFO 203 is a required course for the UC-Berkeley&apos;s Master of Information Management &amp; Systems (MIMS) program, and open to graduate students from all departments."
---

INFO 203 is a required course for the UC-Berkeley&apos;s Master of Information Management &amp; Systems (MIMS) program, and open to graduate students from all departments. The course covers fundamental topics in social informatics, human-computer interaction, and science &amp; technology studies. My duties included: Grading assignments; holding weekly office hours; assisting students with writing and final projects; giving two 1.5 hour lectures per semester.  -->
