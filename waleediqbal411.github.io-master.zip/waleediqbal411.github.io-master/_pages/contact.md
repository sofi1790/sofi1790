---
layout: archive
title: "Contact"
permalink: /contact/
author_profile: true
---

Contact information is below, including email and various web services.

* E-mail: w[dot]iqbal[at]qmul[dot]ac[dot]uk
* Twitter: [waleediqbal411](https://twitter.com/waleediqbal411)
* Google Scholar: [Waleed Iqbal](https://scholar.google.com/citations?hl=en&user=uXhMEBsAAAAJ)
* Researchgate: [Waleed Iqbal](https://www.researchgate.net/profile/Waleed_Iqbal)
* LinkedIn: [waleediqbal411](https://www.linkedin.com/in/waleediqbal411/)